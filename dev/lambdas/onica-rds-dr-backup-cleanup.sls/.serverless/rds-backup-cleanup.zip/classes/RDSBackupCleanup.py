import botocore  
import datetime  
import logging
import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

class RDSBackupCleanup:

    def __init__(self,dr_region):
            self.my_rds_primary = boto3.client('rds')
            self.my_rds_dr = boto3.client('rds',region_name=dr_region)
            
    def get_rds_instance(self,instances):   
        try:
            result = False
            for instance in instances:
                logger.info("Checking if RDS instance: " + instance + " exists")
                response = self.my_rds_primary.describe_db_instances(
                    DBInstanceIdentifier=instance
                )

            if 'DBInstances' in response:
                logger.info("RDS Instance exists")
                result = True
            else:
                logger.info("RDS Instance does not exist")
            return result
        
        except botocore.exceptions.ClientError as error:
            if error.response['Error']['Code'] == 'ResourceNotFound':
                logger.info("RDS instance does not exist. Returning false")
            return False

        except Exception as e:
            logger.error('Class RDSBackupCleanup. Method get_rds_instance failed with error: ' + str(e))
    
    def delete_rds_snapshot_primary(self, instances):          
        try:
            retention_days = (datetime.datetime.now() - datetime.timedelta(days=14)).strftime('%Y-%m-%d')
            
            for instance in [instances]:
                logger.info("Setting variable for RDS snapshot retention date")
                
                logger.info("Retrieving current RDS instance snapshots")
                rds_snapshots = self.my_rds_primary.describe_db_snapshots(
                DBInstanceIdentifier=instance,
                Filters=[
                    {
                        'Name': 'snapshot-type',
                        'Values': [
                            'manual',
                            ]
                        }
                    ]
                )
                logger.info("Checking if RDS snapshot creation date is less than retention date, and lambda-dr found in snapshot id")
                for snapshot in rds_snapshots['DBSnapshots']:
                    if snapshot['SnapshotCreateTime'].strftime('%Y-%m-%d') < retention_days and 'lambda-dr' in snapshot['DBSnapshotIdentifier']:
                        logger.info("Deleting RDS snapshots that are less than retention date")
                    snapshot_delete = self.my_rds_primary.delete_db_snapshot(DBSnapshotIdentifier=snapshot['DBSnapshotIdentifier'])
                    status = snapshot_delete['DBSnapshot']['Status']
                    logger.info("RDS instance" + instance + "snapshot status is now" + status)
            return status
        
        except Exception as e:
            logger.error('Class RDSBackupCleanup Method delete_rds_snapshot failed with error: ' + str(e))
            
            
    def delete_rds_snapshot_dr(self, instances):          
        try:
            retention_days = (datetime.datetime.now() - datetime.timedelta(days=14)).strftime('%Y-%m-%d')
            
            for instance in [instances]:
                logger.info("Setting variable for RDS snapshot retention date")
                
                logger.info("Retrieving current RDS instance snapshots")
                rds_snapshots = self.my_rds_dr.describe_db_snapshots(
                DBInstanceIdentifier=instance,
                Filters=[
                    {
                        'Name': 'snapshot-type',
                        'Values': [
                            'manual',
                            ]
                        }
                    ]
                )
                logger.info("Checking if RDS snapshot creation date is less than retention date, and lambda-dr found in snapshot id")
                for snapshot in rds_snapshots['DBSnapshots']:
                    if snapshot['SnapshotCreateTime'].strftime('%Y-%m-%d') < retention_days and 'lambda-dr' in snapshot['DBSnapshotIdentifier']:
                        logger.info("Deleting RDS snapshots that are less than retention date")
                    snapshot_delete = self.my_rds_dr.delete_db_snapshot(DBSnapshotIdentifier=snapshot['DBSnapshotIdentifier'])
                    status = snapshot_delete['DBSnapshot']['Status']
                    logger.info("RDS instance" + instance + "snapshot status is now" + status)
            return status
        
        except Exception as e:
            logger.error('Class RDSBackupCleanup Method delete_rds_snapshot failed with error: ' + str(e))
                
                
                
         
    
    